from __future__ import annotations

import typing as t

from collections import Counter, defaultdict
from itertools import chain

from sqlglot import expressions as exp
from sqlglot.helper import find_new_name, seq_get
from sqlglot.optimizer.helpers import is_implicit_group_by_all, projection_has_aggregate
from sqlglot.optimizer.scope import Scope, find_all_in_scope, traverse_scope

if t.TYPE_CHECKING:
    from sqlglot._typing import E

    FromOrJoin = t.Union[exp.From, exp.Join]


class CopyBudget:
    """
    Merging copies an inner projection into every outer reference to it, so chained merges of
    repeatedly referenced projections can grow the AST exponentially. The number of copied nodes
    is capped per statement, relative to its size, and merges that would exceed the cap are skipped.
    """

    MAX_COPY_FACTOR = 8
    """Smallest factor that changed no ordinary query among 1,121 real-world queries"""

    MIN_COPY_BUDGET = 1000
    """Spares small statements"""

    def __init__(
        self,
        expression: exp.Expr,
        max_copy_factor: int | None = MAX_COPY_FACTOR,
        min_copy_budget: int = MIN_COPY_BUDGET,
    ) -> None:
        self.expression = expression
        self.max_copy_factor = max_copy_factor
        self.min_copy_budget = min_copy_budget
        self.remaining: int | None = None

    def consume(self, outer_scope: Scope, inner_scope: Scope, alias: str) -> bool:
        """Charges the copies needed to merge `inner_scope` into `outer_scope`, if they fit."""
        if self.max_copy_factor is None:
            return True

        if self.remaining is None:
            # Sized on first use, which precedes any merge, so statements with nothing to merge skip it
            size = sum(1 for _ in self.expression.walk())
            self.remaining = max(self.max_copy_factor * size, self.min_copy_budget)

        references = Counter(c.name for c in outer_scope.columns if c.table == alias)
        copies = 0
        for projection in inner_scope.expression.expressions:
            # The last reference receives the projection itself rather than a copy
            count = references.get(projection.alias_or_name, 0) - 1
            if count > 0:
                for _ in projection.unalias().walk():
                    copies += count
                    if copies > self.remaining:
                        return False

        self.remaining -= copies
        return True


def merge_subqueries(
    expression: E,
    leave_tables_isolated: bool = False,
    max_copy_factor: int | None = CopyBudget.MAX_COPY_FACTOR,
    min_copy_budget: int = CopyBudget.MIN_COPY_BUDGET,
) -> E:
    """
    Rewrite sqlglot AST to merge derived tables into the outer query.

    This also merges CTEs if they are selected from only once.

    Example:
        >>> import sqlglot
        >>> expression = sqlglot.parse_one("SELECT a FROM (SELECT x.a FROM x) CROSS JOIN y")
        >>> merge_subqueries(expression).sql()
        'SELECT x.a FROM x CROSS JOIN y'

    If `leave_tables_isolated` is True, this will not merge inner queries into outer
    queries if it would result in multiple table selects in a single query:
        >>> expression = sqlglot.parse_one("SELECT a FROM (SELECT x.a FROM x) CROSS JOIN y")
        >>> merge_subqueries(expression, leave_tables_isolated=True).sql()
        'SELECT a FROM (SELECT x.a FROM x) CROSS JOIN y'

    Inspired by https://dev.mysql.com/doc/refman/8.0/en/derived-table-optimization.html

    Args:
        expression (sqlglot.Expr): expression to optimize
        leave_tables_isolated (bool):
        max_copy_factor: see `CopyBudget.MAX_COPY_FACTOR`; `None` disables the copy budget.
        min_copy_budget: see `CopyBudget.MIN_COPY_BUDGET`.
    Returns:
        sqlglot.Expr: optimized expression
    """
    # Shared across both passes so the scope tree is only built once, as long as merge_ctes
    # doesn't mutate the AST; if it does, the scopes it was given are no longer valid, so the
    # scope tree needs to be rebuilt before merge_derived_tables runs.
    scopes = traverse_scope(expression)

    copy_budget = CopyBudget(
        expression, max_copy_factor=max_copy_factor, min_copy_budget=min_copy_budget
    )
    expression, merged_ctes = merge_ctes(
        expression, leave_tables_isolated, scopes=scopes, copy_budget=copy_budget
    )

    if merged_ctes:
        scopes = traverse_scope(expression)

    expression = merge_derived_tables(
        expression, leave_tables_isolated, scopes=scopes, copy_budget=copy_budget
    )
    return expression


# If a derived table has these Select args, it can't be merged
UNMERGABLE_ARGS = set(exp.Select.arg_types) - {
    "expressions",
    "from_",
    "joins",
    "where",
    "order",
    "hint",
}


# Projections in the outer query that are instances of these types can be replaced
# without getting wrapped in parentheses, because the precedence won't be altered.
SAFE_TO_REPLACE_UNWRAPPED = (
    exp.Column,
    exp.Func,
    exp.Paren,
)


# These Binary subclasses are opaque to the NULL-propagation check. This is a
# conservative list, not a claim that every instance returns a non-NULL value.
NULL_PROPAGATION_EXCEPTIONS = (
    exp.Func,  # Binary functions include AND/OR, which need not propagate NULL.
    exp.Is,  # IS NULL/TRUE/FALSE return booleans for NULL inputs.
    exp.NullSafeEQ,
    exp.NullSafeNEQ,
    exp.Match,  # MATCH can invoke a user-defined function, e.g., in SQLite.
    exp.DPipe,  # Concatenation ignores NULL operands in some dialects.
    exp.NestedJSONSelect,  # Dialect-specific JSON field access.
    exp.Operator,  # User-defined operators have unknown NULL behavior.
    exp.PropertyEQ,  # Named field syntax: name := value.
    exp.Kwarg,  # Named argument syntax: name => value.
)


def merge_ctes(
    expression: E,
    leave_tables_isolated: bool = False,
    scopes: list[Scope] | None = None,
    copy_budget: CopyBudget | None = None,
) -> tuple[E, bool]:
    copy_budget = copy_budget or CopyBudget(expression)
    scopes = traverse_scope(expression) if scopes is None else scopes
    scope_lookup = {id(scope.expression): scope for scope in scopes}

    # All places where we select from CTEs.
    # We key on the CTE scope so we can detect CTES that are selected from multiple times.
    cte_selections = defaultdict(list)
    for outer_scope in scopes:
        for table, inner_scope in outer_scope.selected_sources.values():
            if isinstance(inner_scope, Scope) and inner_scope.is_cte:
                cte_selections[id(inner_scope)].append(
                    (
                        outer_scope,
                        inner_scope,
                        table,
                    )
                )

    merged = False
    singular_cte_selections = [v[0] for k, v in cte_selections.items() if len(v) == 1]
    for outer_scope, inner_scope, table in singular_cte_selections:
        from_or_join = table.find_ancestor(exp.From, exp.Join)
        if not isinstance(from_or_join, (exp.From, exp.Join)):
            continue
        alias = table.alias_or_name
        if _mergeable(
            outer_scope, inner_scope, leave_tables_isolated, from_or_join, table, scope_lookup
        ) and copy_budget.consume(outer_scope, inner_scope, alias):
            _rename_inner_sources(outer_scope, inner_scope, alias, scope_lookup)
            _merge_from(outer_scope, inner_scope, table, alias)
            _merge_expressions(outer_scope, inner_scope, alias)
            _merge_order(outer_scope, inner_scope)
            _merge_joins(outer_scope, inner_scope, from_or_join)
            _merge_where(outer_scope, inner_scope, from_or_join)
            _merge_hints(outer_scope, inner_scope)
            _pop_cte(inner_scope)
            outer_scope.clear_cache()
            merged = True
    return expression, merged


def merge_derived_tables(
    expression: E,
    leave_tables_isolated: bool = False,
    scopes: list[Scope] | None = None,
    copy_budget: CopyBudget | None = None,
) -> E:
    copy_budget = copy_budget or CopyBudget(expression)
    scopes = traverse_scope(expression) if scopes is None else scopes
    scope_lookup = {id(scope.expression): scope for scope in scopes}

    for outer_scope in scopes:
        for subquery in outer_scope.derived_tables:
            from_or_join = subquery.find_ancestor(exp.From, exp.Join)
            if not isinstance(from_or_join, (exp.From, exp.Join)):
                continue
            alias = subquery.alias_or_name
            inner_scope = outer_scope.sources[alias]
            if not isinstance(inner_scope, Scope):
                continue
            if _mergeable(
                outer_scope,
                inner_scope,
                leave_tables_isolated,
                from_or_join,
                subquery,
                scope_lookup,
            ) and copy_budget.consume(outer_scope, inner_scope, alias):
                _rename_inner_sources(outer_scope, inner_scope, alias, scope_lookup)
                _merge_from(outer_scope, inner_scope, subquery, alias)
                _merge_expressions(outer_scope, inner_scope, alias)
                _merge_order(outer_scope, inner_scope)
                _merge_joins(outer_scope, inner_scope, from_or_join)
                _merge_where(outer_scope, inner_scope, from_or_join)
                _merge_hints(outer_scope, inner_scope)
                outer_scope.clear_cache()

    return expression


def _mergeable(
    outer_scope: Scope,
    inner_scope: Scope,
    leave_tables_isolated: bool,
    from_or_join: FromOrJoin,
    source: exp.Selectable,
    scope_lookup: dict[int, Scope],
) -> bool:
    """
    Return True if `inner_select` can be merged into outer query.
    """
    inner_select = inner_scope.expression.unnest()
    outer = outer_scope.expression
    outer_args = outer.args
    inner_name = source.alias_or_name

    def _constant_projection_empties_group_by_all(column_free_aliases: set[str]) -> bool:
        """
        GROUP BY ALL infers its keys from the SELECT list, but engines (e.g. DuckDB) drop any
        column-free SELECT item from that inferred set, unlike a column reference to the same
        constant. Only unsafe if inlining would empty out every remaining key; a constant key
        beside a real column key is harmless.
        """
        if not column_free_aliases or not is_implicit_group_by_all(t.cast(exp.Select, outer)):
            return False

        windows = outer_args.get("windows")
        for s in t.cast(exp.Select, outer).selects:
            if projection_has_aggregate(s, windows):
                continue
            if any(
                column.table != inner_name or column.name not in column_free_aliases
                for column in find_all_in_scope(s, exp.Column)
            ):
                return False

        return True

    def _window_projection_blocks_merge(window_aliases: set[str]) -> bool:
        """A window function's result depends on the full row set it sees, so merging the
        subquery into the outer query is unsafe when:
          - the outer query filters or joins (WHERE/JOIN), which changes that row set,
          - the outer query is a bare GROUP BY ALL, which implicitly groups by every
            projection (unlike ALL as a grouping-sets modifier, e.g. GROUP BY ALL
            CUBE (...)), or
          - a window column is referenced in an operation that isn't pushed down
            (GROUP BY, ORDER BY, HAVING, aggregate).
        """
        if not window_aliases:
            return False

        if outer_args.get("where") or outer_args.get("joins"):
            return True

        if is_implicit_group_by_all(t.cast(exp.Select, outer)):
            return True

        return any(
            column.table == inner_name
            and column.name in window_aliases
            and column.find_ancestor(exp.Group, exp.Order, exp.Having, exp.AggFunc)
            for column in outer_scope.columns
        )

    def _literal_group_unmergeable(number_literal_aliases: set[str]) -> bool:
        """
        A numeric-literal projection referenced in GROUP BY can't be inlined, because a bare
        integer literal is positional. A reference that is itself a top-level GROUP BY item
        can merge as the ordinal of the outer projection that selects it; any other reference,
        e.g., ROLLUP / CUBE / GROUPING SETS, tuples, expressions, etc, blocks the merge, since
        ordinals aren't universally supported there, e.g., Presto / Trino only accept columns.
        """
        group = outer_args.get("group")
        if not group:
            return False

        if not number_literal_aliases:
            return False

        grouped = set()
        top_level_ids = {id(e.unnest()) for e in group.expressions}
        for col in group.find_all(exp.Column):
            if col.table != inner_name or col.name not in number_literal_aliases:
                continue
            if id(col) not in top_level_ids:
                return True
            grouped.add(col.name)

        if not grouped:
            return False

        projected = set()
        for s in t.cast(exp.Select, outer).selects:
            unaliased = s.unalias()
            if isinstance(unaliased, exp.Column) and unaliased.table == inner_name:
                projected.add(unaliased.name)

        return not grouped <= projected

    def _outer_select_joins_on_inner_select_join(projections: dict[str, exp.Expr]) -> bool:
        """
        All columns from the inner select in the ON clause must be from the first FROM table.

        That is, this can be merged:
            SELECT * FROM x JOIN (SELECT y.a AS a FROM y JOIN z) AS q ON x.a = q.a
                                         ^^^           ^
        But this can't:
            SELECT * FROM x JOIN (SELECT z.a AS a FROM y JOIN z) AS q ON x.a = q.a
                                         ^^^                  ^
        """
        if not isinstance(from_or_join, exp.Join):
            return False

        on = from_or_join.args.get("on")
        if not on:
            return False
        selections = [c.name for c in find_all_in_scope(on, exp.Column) if c.table == inner_name]
        inner_from = inner_scope.expression.args.get("from_")
        if not inner_from:
            return False
        inner_from_table = inner_from.alias_or_name
        return any(
            col.table != inner_from_table
            for selection in selections
            for col in projections[selection].find_all(exp.Column)
        )

    def _is_recursive() -> bool:
        # Recursive CTEs look like this:
        #     WITH RECURSIVE cte AS (
        #       SELECT * FROM x  <-- inner scope
        #       UNION ALL
        #       SELECT * FROM cte  <-- outer scope
        #     )
        cte = inner_scope.expression.parent
        node = outer.parent

        while node:
            if node is cte:
                return True
            node = node.parent
        return False

    def _literal_in_order_by(number_literal_aliases: set[str]) -> bool:
        """A numeric-literal projection under a bare ORDER BY key can't merge (would become positional)."""
        order = outer_args.get("order")
        if not order:
            return False
        ordered = {
            key.name
            for o in order.expressions
            if isinstance(key := o.this.unnest(), exp.Column) and key.table == inner_name
        }
        return bool(number_literal_aliases & ordered)

    def _is_null_propagating(expression: exp.Expr) -> bool:
        """Conservatively check whether the projection is NULL when all inner sources are NULL."""
        stack = [expression]
        while stack:
            node = stack.pop().unalias().unnest()
            if isinstance(node, exp.Null) or (
                isinstance(node, exp.Column) and node.table in inner_scope.selected_sources
            ):
                return True
            if isinstance(node, exp.Dot):
                if isinstance(node.expression, exp.Identifier):
                    stack.append(node.this)
            elif isinstance(node, (exp.Cast, exp.Unary)):
                stack.append(node.this)
            elif isinstance(node, exp.Binary) and not isinstance(node, NULL_PROPAGATION_EXCEPTIONS):
                stack.extend((node.expression, node.this))
        return False

    def _outer_join_blocks_merge(projections: dict[str, exp.Expr]) -> bool:
        node: exp.Expr = source
        joins = node.args.get("joins", [])
        while True:
            if (isinstance(node, exp.Join) and node.side in ("LEFT", "FULL")) or any(
                j.side in ("RIGHT", "FULL") for j in joins
            ):
                break
            if node is outer or not node.parent:
                return False
            # Include later joins and enclosing parenthesized joins that null-extend this source.
            start = node.index + 1 if node.arg_key == "joins" and node.index is not None else 0
            joins = node.parent.args.get("joins", [])[start:]
            node = node.parent

        referenced = {c.name for c in outer_scope.columns if c.table == inner_name}
        return any(
            name in referenced and not _is_null_propagating(projection)
            for name, projection in projections.items()
        )

    if (
        not isinstance(outer, exp.Select)
        or outer.is_star
        or not isinstance(inner_select, exp.Select)
        or any(v for k, v in inner_select.args.items() if k in UNMERGABLE_ARGS)
        or inner_select.args.get("from_") is None
        or outer_scope.pivots
        # Merging can move filters and projections across row pairing and padding.
        or any(
            join.method in ("ASOF", "POSITIONAL")
            or join.kind in ("ASOF", "ANY", "PASTE")
            or join.args.get("nearest")
            for scope in (outer_scope, inner_scope)
            for join in scope.find_all(exp.Join)
        )
        or (leave_tables_isolated and len(outer_scope.selected_sources) > 1)
        or (isinstance(from_or_join, exp.Join) and inner_select.args.get("joins"))
        or (
            isinstance(from_or_join, exp.Join)
            and inner_select.args.get("where")
            and from_or_join.side in ("FULL", "LEFT", "RIGHT")
        )
        or (
            isinstance(from_or_join, exp.From)
            and inner_select.args.get("where")
            and any(j.side in ("FULL", "RIGHT") for j in outer_args.get("joins", []))
        )
        or (inner_select.args.get("order") and outer_scope.is_set_operation)
        or isinstance(seq_get(inner_select.expressions, 0), exp.QueryTransform)
    ):
        return False

    # Single pass over the projections: replaces the separate AggFunc/Select/Explode and
    # Window tree walks, and precomputes what the checks below need per-projection.
    window_aliases: set[str] = set()
    number_literal_aliases: set[str] = set()
    column_free_aliases: set[str] = set()
    projections: dict[str, exp.Expr] = {}

    for s in inner_select.selects:
        name = s.alias_or_name
        projections[name] = s
        if s.unalias().is_number:
            number_literal_aliases.add(name)
        has_column = False
        for node in s.walk():
            if isinstance(node, (exp.AggFunc, exp.Select, *exp.SET_RETURNING_FUNCTIONS)):
                return False
            if isinstance(node, exp.Window):
                window_aliases.add(name)
            if isinstance(node, exp.Column):
                has_column = True
        if not has_column:
            column_free_aliases.add(name)

    external_sources = {column.table for column in inner_scope.external_columns}
    if external_sources:
        # Ancestor sources cannot be renamed here, so skip merges that would capture them.
        if external_sources.intersection(
            name for name, _ in outer_scope.references if name != inner_name
        ):
            return False

        outer_columns = outer_scope.source_columns(inner_name)
        for name, projection in projections.items():
            sources = external_sources.intersection(
                column.table for column in projection.find_all(exp.Column)
            )
            if sources and sources.intersection(
                _nested_source_names(
                    outer_scope,
                    (column for column in outer_columns if column.name == name),
                    scope_lookup,
                )
            ):
                return False

    return (
        not _constant_projection_empties_group_by_all(column_free_aliases)
        and not _outer_select_joins_on_inner_select_join(projections)
        and not _window_projection_blocks_merge(window_aliases)
        and not _literal_group_unmergeable(number_literal_aliases)
        and not _literal_in_order_by(number_literal_aliases)
        and not _outer_join_blocks_merge(projections)
        and not (inner_scope.is_cte and _is_recursive())
    )


def _nested_source_names(
    scope: Scope, columns: t.Iterable[exp.Expr], scope_lookup: dict[int, Scope]
) -> set[str]:
    names: set[str] = set()
    seen = {id(scope.expression)}
    for column in columns:
        if id(column) in scope.column_index:
            continue

        # Only scopes on a reference's path can capture it. Shared paths are visited once.
        node = column.parent
        while node is not None and id(node) not in seen:
            seen.add(id(node))
            if nested_scope := scope_lookup.get(id(node)):
                names.update(name for name, _ in nested_scope.references)
            node = node.parent

    return names


def _rename_inner_sources(
    outer_scope: Scope, inner_scope: Scope, alias: str, scope_lookup: dict[int, Scope]
) -> None:
    """
    Renames any sources in the inner query that conflict with names in the outer query.
    """
    inner_taken = set(inner_scope.selected_sources)
    outer_taken = {name for name, _ in outer_scope.references if name != alias}
    outer_taken.update(column.table for column in outer_scope.external_columns)
    outer_taken.update(
        _nested_source_names(outer_scope, outer_scope.source_columns(alias), scope_lookup)
    )

    conflicts = outer_taken.intersection(inner_taken)
    if not conflicts:
        return

    taken = outer_taken.union(name for name, _ in inner_scope.references)
    taken.update(column.table for column in inner_scope.external_columns)
    table_columns = [
        column
        for scope in inner_scope.traverse()
        for column in scope.table_columns
        if column.name in conflicts
        and column.name not in _nested_source_names(inner_scope, (column,), scope_lookup)
    ]
    taken.update(
        _nested_source_names(
            inner_scope,
            chain(
                (column for column in inner_scope.columns if column.table in conflicts),
                table_columns,
            ),
            scope_lookup,
        )
    )

    for conflict in conflicts:
        new_name = find_new_name(taken, conflict)
        taken.add(new_name)

        source, _ = inner_scope.selected_sources[conflict]
        alias_holder = source.parent if isinstance(source.parent, exp.Subquery) else source
        table_alias = alias_holder.args.get("alias") or exp.TableAlias()
        table_alias.set("this", exp.to_identifier(new_name))
        alias_holder.set("alias", table_alias)

        for join_hint in inner_scope.join_hints:
            for table in join_hint.find_all(exp.Table):
                if table.alias_or_name == conflict:
                    table.set("this", exp.to_identifier(new_name))

        for column in inner_scope.source_columns(conflict):
            column.set("table", exp.to_identifier(new_name))

        for table_column in table_columns:
            if table_column.name == conflict:
                table_column.set("this", exp.to_identifier(new_name))

        inner_scope.rename_source(conflict, new_name)


def _merge_from(
    outer_scope: Scope,
    inner_scope: Scope,
    node_to_replace: exp.Selectable,
    alias: str,
) -> None:
    """
    Merge FROM clause of inner query into outer query.
    """
    new_subquery = inner_scope.expression.args["from_"].this
    new_subquery.set("joins", node_to_replace.args.get("joins"))
    node_to_replace.replace(new_subquery)
    for join_hint in outer_scope.join_hints:
        tables = join_hint.find_all(exp.Table)
        for table in tables:
            if table.alias_or_name == node_to_replace.alias_or_name:
                table.set("this", exp.to_identifier(new_subquery.alias_or_name))
    outer_scope.remove_source(alias)
    outer_scope.add_source(
        new_subquery.alias_or_name, inner_scope.sources[new_subquery.alias_or_name]
    )


def _merge_joins(outer_scope: Scope, inner_scope: Scope, from_or_join: FromOrJoin) -> None:
    """
    Merge JOIN clauses of inner query into outer query.
    """

    new_joins = []

    joins = inner_scope.expression.args.get("joins") or []

    for join in joins:
        new_joins.append(join)
        outer_scope.add_source(join.alias_or_name, inner_scope.sources[join.alias_or_name])

    if new_joins:
        outer_joins = outer_scope.expression.args.get("joins", [])

        # Maintain the join order
        if isinstance(from_or_join, exp.From):
            position = 0
        else:
            position = outer_joins.index(from_or_join) + 1
        outer_joins[position:position] = new_joins

        outer_scope.expression.set("joins", outer_joins)


def _merge_expressions(outer_scope: Scope, inner_scope: Scope, alias: str) -> None:
    """
    Merge projections of inner query into outer query.

    Args:
        outer_scope (sqlglot.optimizer.scope.Scope)
        inner_scope (sqlglot.optimizer.scope.Scope)
        alias (str)
    """
    # Collect all columns that reference the alias of the inner query
    outer_columns = defaultdict(list)
    for column in outer_scope.columns:
        if column.table == alias:
            outer_columns[column.name].append(column)

    group = outer_scope.expression.args.get("group")

    # Replace columns with the projection expression in the inner query
    for expression in inner_scope.expression.expressions:
        projection_name = expression.alias_or_name
        if not projection_name:
            continue
        columns_to_replace = outer_columns.get(projection_name, [])
        if not columns_to_replace:
            continue

        expression = expression.unalias()

        is_number = expression.is_number
        last = len(columns_to_replace) - 1

        group_ordinal = None
        if is_number and isinstance(outer_scope.expression, exp.Select):
            # Find the ordinal of the outer SELECT that references this inner projection.
            for j, s in enumerate(outer_scope.expression.selects):
                unaliased = s.unalias()
                if (
                    isinstance(unaliased, exp.Column)
                    and unaliased.table == alias
                    and unaliased.name == projection_name
                ):
                    group_ordinal = j + 1
                    break

        for i, column in enumerate(columns_to_replace):
            parent = column.parent

            # A numeric-literal projection can't be inlined into a top-level GROUP BY item
            # (positional context), canonicalize to the projection's ordinal to match
            # qualify. _mergeable guarantees the ordinal exists.
            if is_number and group:
                item = next((e for e in group.expressions if e.unnest() is column), None)
                if item is not None:
                    item.replace(exp.Literal.number(group_ordinal))
                    continue

            # Skip the expensive deep copy for the last reference since the inner query
            # is about to be removed, so we can move the expression directly
            replacement = expression.copy() if i < last else expression

            # Ensures we don't alter the intended operator precedence if there's additional
            # context surrounding the outer expression (i.e. it's not a simple projection).
            if _must_wrap(expression, column):
                replacement = exp.paren(replacement, copy=False)

            # make sure we do not accidentally change the name of the column
            if isinstance(parent, exp.Select) and column.name != expression.name:
                replacement = exp.alias_(replacement, column.name, copy=False)

            column.replace(replacement)

    if outer_columns:
        for scope in outer_scope.traverse():
            scope.clear_cache()


def _must_wrap(expression: exp.Expr, column: exp.Column) -> bool:
    parent = column.parent

    if isinstance(parent, exp.Paren) or not (
        isinstance(parent, (exp.Unary, exp.Binary, exp.Between))
        or (isinstance(parent, exp.In) and column.arg_key == "this")
    ):
        return False

    # AND / OR are Funcs, but they bind looser than any operator they can be nested in
    if isinstance(expression, exp.Connector):
        return True

    # = and <> are safe under AND / OR, but e.g. Postgres binds IN and BETWEEN tighter than them
    if isinstance(expression, (exp.EQ, exp.NEQ)):
        return not isinstance(parent, exp.Connector)

    return not isinstance(expression, SAFE_TO_REPLACE_UNWRAPPED)


def _merge_where(outer_scope: Scope, inner_scope: Scope, from_or_join: FromOrJoin) -> None:
    """
    Merge WHERE clause of inner query into outer query.

    Args:
        outer_scope (sqlglot.optimizer.scope.Scope)
        inner_scope (sqlglot.optimizer.scope.Scope)
        from_or_join (exp.From|exp.Join)
    """
    where = inner_scope.expression.args.get("where")
    if not where or not where.this:
        return

    expression = outer_scope.expression

    if isinstance(from_or_join, exp.Join):
        # Merge predicates from an outer join to the ON clause
        # if it only has columns that are already joined
        from_ = expression.args.get("from_")
        sources = {from_.alias_or_name} if from_ else set()

        for join in expression.args["joins"]:
            source = join.alias_or_name
            sources.add(source)
            if source == from_or_join.alias_or_name:
                break

        if exp.column_table_names(where.this) <= sources:
            from_or_join.on(where.this, copy=False)
            from_or_join.set("on", from_or_join.args.get("on"))
            return

    t.cast(exp.Select, expression).where(where.this, copy=False)


def _merge_order(outer_scope: Scope, inner_scope: Scope) -> None:
    """
    Merge ORDER clause of inner query into outer query.

    Args:
        outer_scope (sqlglot.optimizer.scope.Scope)
        inner_scope (sqlglot.optimizer.scope.Scope)
    """
    inner_order = inner_scope.expression.args.get("order")
    if not inner_order:
        return

    if (
        any(
            outer_scope.expression.args.get(arg) for arg in ["group", "distinct", "having", "order"]
        )
        or len(outer_scope.selected_sources) != 1
        or any(expression.find(exp.AggFunc) for expression in outer_scope.expression.expressions)
    ):
        return

    outer_scope.expression.set("order", inner_order)


def _merge_hints(outer_scope: Scope, inner_scope: Scope) -> None:
    inner_scope_hint = inner_scope.expression.args.get("hint")
    if not inner_scope_hint:
        return
    outer_scope_hint = outer_scope.expression.args.get("hint")
    if outer_scope_hint:
        for hint_expression in inner_scope_hint.expressions:
            outer_scope_hint.append("expressions", hint_expression)
    else:
        outer_scope.expression.set("hint", inner_scope_hint)


def _pop_cte(inner_scope: Scope) -> None:
    """
    Remove CTE from the AST.

    Args:
        inner_scope (sqlglot.optimizer.scope.Scope)
    """
    cte = inner_scope.expression.parent
    if not cte:
        return
    with_ = cte.parent
    if not with_:
        return
    if len(with_.expressions) == 1:
        with_.pop()
    else:
        cte.pop()
